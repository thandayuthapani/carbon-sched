# CHANGELOG

## v1.0.0-rc1

This is the first logged release.  Major changes (including breaking changes)
have occurred since earlier tags.
