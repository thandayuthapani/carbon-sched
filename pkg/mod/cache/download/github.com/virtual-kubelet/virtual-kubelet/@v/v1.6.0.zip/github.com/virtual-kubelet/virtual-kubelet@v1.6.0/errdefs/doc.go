// Package errdefs defines the error types that are understood by other packages
// in this project. Consumers of this project should look here to know how to
// produce and consume errors for this project.
package errdefs
