## Virtual Kubelet adopters

* Microsoft Azure
* AWS
* Alibaba
* VMWare
* Netflix
* Hashi Corp
* Admiralty
* Elotl
* Tencent Games

Since end-users are specific per provider within VK we have many end-user customers that we don't have permission to list publically. Please contact ribhatia@microsoft.com for more informtation.

Are you currently using Virtual Kubelet in production? Please let us know by adding your company name and a description of your use case to this document!
