Copied from
https://github.com/kubernetes/kubernetes/tree/master/third_party/forked/golang/expansion .

This is to eliminate a direct dependency on kubernetes/kubernetes.
