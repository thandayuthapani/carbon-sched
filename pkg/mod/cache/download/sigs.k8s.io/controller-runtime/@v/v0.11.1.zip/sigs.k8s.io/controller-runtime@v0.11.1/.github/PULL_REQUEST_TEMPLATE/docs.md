<!-- please add a :book: (`:book:`) to the title of this PR, and delete this line and similar ones -->

<!-- What docs does this change, and why? -->
