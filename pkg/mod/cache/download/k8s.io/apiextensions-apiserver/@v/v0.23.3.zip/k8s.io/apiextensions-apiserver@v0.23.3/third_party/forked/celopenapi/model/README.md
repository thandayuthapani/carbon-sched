This directory contains a port of https://github.com/google/cel-policy-templates-go/tree/master/policy/model modified in a few ways:

- Uses the Structural schema types
- All template related code has been removed
