# WARNING ! Please read before using mount functionality
# THIS REPOSITORY is moved : Please use https://github.com/kubernetes/mount-utils for all your work

This package has been moved to new location. Please use the new repo for bug fixes and enhancements.
All existing dependencies on this repo are being removed. Eventually this repo will be deprecated. 
If you are using this repo or planning to use, you must use the new repo mentioned here for this functionality.

New repo : https://github.com/kubernetes/mount-utils 
New go module: k8s.io/mount-utils
For Kubernetes/Kubernetes project the code is available under staging directory. 

