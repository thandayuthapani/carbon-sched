---
title: Argo CD
custom_edit_url: https://github.com/admiraltyio/admiralty/edit/master/docs/user_guide/integrations/argo_cd.md
---

:::caution Under Construction
While we work on this document, check out [ITNEXT's blog post](https://itnext.io/multicluster-scheduler-argo-workflows-across-kubernetes-clusters-ea98016499ca) describing an integration with [Argo CD](https://argoproj.github.io/projects/argo-cd) (scroll down to the relevant section).
:::
